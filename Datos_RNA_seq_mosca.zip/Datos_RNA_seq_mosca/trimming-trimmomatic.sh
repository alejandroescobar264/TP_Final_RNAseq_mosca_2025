#!/bin/bash

# Crear carpeta de salida en el directorio anterior
mkdir -p ../trimming-trimmomatic

# Lista de muestras
samples=("g1_01" "g1_02" "g1_03" "g3_01" "g3_02" "g3_03")

# Bucle para procesar cada muestra
for sample in "${samples[@]}"
do
  echo "Procesando $sample..."

  trimmomatic PE -threads 16 \
    ${sample}_R1.fastq ${sample}_R2.fastq \
    ../trimming-trimmomatic/${sample}_R1_paired.fastq ../trimming-trimmomatic/${sample}_R1_unpaired.fastq \
    ../trimming-trimmomatic/${sample}_R2_paired.fastq ../trimming-trimmomatic/${sample}_R2_unpaired.fastq \
    ILLUMINACLIP:TruSeq3-PE.fa:2:30:10 \
    LEADING:3 TRAILING:3 SLIDINGWINDOW:4:20 MINLEN:36

  echo "$sample procesado."
done

echo "Trimming finalizado. Archivos guardados en ../trimming-trimmomatic"
