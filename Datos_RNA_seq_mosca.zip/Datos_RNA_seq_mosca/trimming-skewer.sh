#!/bin/bash

# Crear carpeta de salida en el directorio anterior
mkdir -p ../trimming-skewer

# Lista de muestras
samples=("g1_01" "g1_02" "g1_03" "g3_01" "g3_02" "g3_03")

# Bucle para procesar cada muestra
for sample in "${samples[@]}"
do
  echo "Procesando $sample..."

    skewer -m pe -q 20 -l 36 -t 16 \
    -o ../trimming-skewer/${sample} \
    ${sample}_R1.fastq ${sample}_R2.fastq

  echo "$sample procesado."
done

echo "Trimming finalizado. Archivos guardados en ../trimming-skewer"
